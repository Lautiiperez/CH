from setuptools import setup

setup(
    name="pedidos",
    version="1.0",
    descripcion="Paquete segunda entrega",
    author="Lautaro Perez",
    author_email="perezlautaro@hotmail.com",
    packages=["Pedidos"],
    scripts=["Pedidos/menu.py"] 
    )